jQuery(document).ready(function($) {
          
  $('#banner-fade').bjqs({
    animtype      : 'slide',
    height        : WQKMFront.height,
    width         : WQKMFront.width,
    responsive    : true,
    randomstart   : true,
	showmarkers   : false,
  });
 
});